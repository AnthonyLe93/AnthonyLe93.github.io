# give objects number-like behavior


class Point():
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __repr__(self):
        return "<Point x:{0},y:{1}>".format(self.x, self.y)

    def __str__(self):
        return "Point ({0}, {1})".format(self.x, self.y)

    # TODO: implement addition
    def __add__(self, other):
        new_point_x = self.x + other.x
        new_point_y = self.y + other.y
        new_point = Point(new_point_x, new_point_y)
        return new_point

    # TODO: implement subtraction
    def __sub__(self, other):
        return Point(self.x - other.x, self.y - other.y)

    # TODO: implement in-place addition
    def __iadd__(self, other):
        self.x += other.x
        self.y += other.y
        return self

    def __isub__(self, other):
        self.x -= other.x
        self.y -= other.y
        return self

def main():
    # Declare some points
    p1 = Point(10, 20)
    p2 = Point(30, 30)
    print(p1, p2)

    # TODO: Add two points
    p3 = p1 + p2
    print(p3)

    # TODO: subtract two points
    p4 = p3 - p2
    print(p4)

    # TODO: Perform in-place addition
    p1 += p3
    print(p1)

if __name__ == "__main__":
    main()
