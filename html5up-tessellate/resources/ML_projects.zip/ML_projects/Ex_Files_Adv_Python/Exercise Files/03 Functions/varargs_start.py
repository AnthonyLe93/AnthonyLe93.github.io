# Demonstrate the use of variable argument lists


# TODO: define a function that takes variable arguments
def addition(*args):
    result = 0
    for arg in args:
        result += arg
    return result


def main():
    # TODO: pass different arguments
    print(addition(5, 12, 4, 1, 6))
    print(addition(7, 23, 8, 2, 9))
    # TODO: pass an existing list
    my_nums = [56, 3, 1, 42, 3]
    print(addition(*my_nums))


if __name__ == "__main__":
    main()
