import unittest
from ann_class import ANN_model


class TestType(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.obj = ANN_model()

    def test_class_construction(self):
        obj = ANN_model()
        msg = 'given object is not an instance of ANN_model'
        self.assertIsInstance(obj, ANN_model, msg)
    def test_prediction_ann_model(self):
        obj = ANN_model()
        x = [[1, 0.56, 1, 1, 1, 0, 1, -1, 0.63]]
        pred = obj.predict_short(x)
        self.assertEqual(pred, ['N'])

if __name__ == '__main__':
    unittest.main()

