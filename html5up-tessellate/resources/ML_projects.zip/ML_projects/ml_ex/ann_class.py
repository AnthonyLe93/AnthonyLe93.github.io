import pandas as pd
from sklearn.neural_network import MLPClassifier
import pickle
import os


class ANN_model():
    """
    this is a class to interact with the trained ann model
    """

    def __init__(self):
        path = os.getcwd() + '/model_exercise.pkl'
        try:
            file = open(path, 'rb')
        except FileNotFoundError:
            print('File does not exit!!!')

        self.model = pickle.load(file)
        file.close()
    def predict(self, season, age, childish, trauma, surgical, fevers, alcohol, smoking, sitting):
        x = [[season, age, childish, trauma, surgical, fevers, alcohol, smoking, sitting]]
        return self.model.predict(x)

    # Passing a panda DataFrame to method - x = [[....]]
    def predict_short(self, parameters):
        return self.model.predict(parameters)

def main():
    model = ANN_model()
    a = 1       # season in which the analysis was performed
    b = 0.56    # age at the time of the analysis
    c = 1       # childish disease
    d = 1       # accident or serious trauma
    e = 1       # surgical intervention
    f = 0       # high fevers in the last year
    g = 1       # frequency of alcohol consumption
    h = -1      # smoking habit
    i = 0.63    # number of hours spent sitting per day

    pred = model.predict(season=a,
                          age=b,
                          childish=c,
                          trauma=d,
                          surgical=e,
                          fevers=f,
                          alcohol=g,
                          smoking=h,
                          sitting=i)

    print(pred)

if __name__ == '__main__':
    main()